#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MEM_UP 0x100102
#define MEM_CLEAR 0x100304
int main(int argc,char *argv[])
{
   int fd,n,res;
   char buf[128];
   fd=open(argv[1],O_RDWR);
   if(fd==-1)
      printf("fail to open %s\n",argv[1]);
   if((n=write(fd,argv[2],strlen(argv[2])))<=0)
      printf("fail to write to %s\n",argv[1]);
   //memset(buf,0,sizeof(buf));
   //lseek(fd, 0, SEEK_SET);
   res=read(fd,buf,strlen(argv[2]));   
   printf("%d,buf=%s\n",res,buf);
   //if(argv[3] == "up"){
      ioctl(fd,MEM_UP);
   //else if(argv[3] == "clean")
      ioctl(fd,MEM_CLEAR);
   
   close(fd);
   return 0;
}
