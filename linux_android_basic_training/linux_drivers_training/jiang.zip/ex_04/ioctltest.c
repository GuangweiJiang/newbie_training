#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MEM_UP 0x100002
#define MEM_CLEAR 0x10004
int main(int argc,char *argv[])
{
   int fd;
   fd=open(argv[1],O_RDWR);
   if((ioctl(fd,MEM_UP))>0)
       return -1;
   printf("ioctl is successful\n");

}
