#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MEM_UP 0x100002
#define MEM_CLEAR 0x10004
int main()
{
   int fd;
   char buf1[100];
   //char buf2[30]="jiang zhen hua";
   //printf("%s\n",buf2);
   //memset(buf2,0,sizeof(buf2));
   fd=open("/dev/globalmem_dev",O_RDWR);
   if((write(fd,"jiang zhen hua",strlen("jiang zhen hua")))<0)
	      printf("fail to writen\n");
   printf("write successfully\n");
   memset(buf1,0,sizeof(buf1));
   if((read(fd,buf1,strlen("jiang zhen hua")))<0)
      printf("fail to read\n");
      printf("read successfully\n");
   buf1[100]='\0';
   //ioctl(fd,MEM_UP);
   ioctl(fd,MEM_CLEAR);
   printf("ioctl is successful\n");

}
