//==========================================
// Filename:
//      PvButton.java
//
// Copyright (C) 2010 Wistron
// All rights reserved.
//
// Description:
//      This is demo code to show how to custom a button based on View.
//		The custom PvButton attributes are defined in the attrs.xml.
//
// Author/Created Date:
//      Guangwei Jiang, Jul19'10
//
// Modification History:
//		By Guangwei Jiang@Aug31'10 
//		1. Remove the customized method to set background, 
//		   use the "view" default attributes and method to set and change the background.
//
//
// Note:
//	Current version Num: v1.1  
//
//==========================================
//
// 
//

package com.wistron.CustomView;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

public class PvButton extends View{
	private String 	mText	= null;
	private Bitmap 	mImage 	= null;
	private Paint   mPaint	= null; 

	public PvButton(Context context) {
		super(context);
		 
		mPaint = new Paint();
	}
	
	public PvButton(Context context, AttributeSet attrs) {
		super(context, attrs);		

		mPaint = new Paint();
		
		TypedArray params = context.obtainStyledAttributes(attrs,R.styleable.PvButton);   
		  
		// Remove the customized method to set background, 
		// use the "view" default attributes and method to set and change the background.
		// By Guangwei@Aug31'10
		/*int backgroudId = params.getResourceId(R.styleable.PvButton_backGround,0);   
		if (backgroudId != 0)    
		{   
			setBackgroundResource(backgroudId);   
		}*/   
		
		Drawable drawable = params.getDrawable(R.styleable.PvButton_imageDrawable);
        if (drawable != null) {
        	mImage = ((BitmapDrawable) drawable).getBitmap();
        }
			
		mText = params.getString(R.styleable.PvButton_text);
        
		
		
		int textColor = params.getColor(R.styleable.PvButton_textColor,0XFFFFFFFF);   
		mPaint.setColor(textColor);   
		  
		float textSize = params.getDimension(R.styleable.PvButton_textSize, 20);   
		mPaint.setTextSize(textSize);  
	}
	
	/**
     * Sets the text to display in this label
     * @param text The text to display. This will be drawn as one line.
     */
    public void setText(String text) {
        mText = text;
        requestLayout();
        invalidate();
    }
	
	protected void onDraw(Canvas canvas)    
	{   
		super.onDraw(canvas);   

		canvas.drawBitmap(mImage, getPaddingLeft()+30, getPaddingTop()-mPaint.ascent()/2, mPaint);		   
		canvas.drawText(mText, getPaddingLeft()+20, getPaddingTop()-mPaint.ascent()+80, mPaint); 
	}  
}
