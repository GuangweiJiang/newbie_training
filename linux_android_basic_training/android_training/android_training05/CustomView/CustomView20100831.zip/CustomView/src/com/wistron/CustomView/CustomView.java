//==========================================
// Filename:
//      CustomView.java
//
// Copyright (C) 2010 Wistron
// All rights reserved.
//
// Description:
//      This is demo code to show how to use custom button.
//
// Author/Created Date:
//      Guangwei Jiang, Jul19'10
//
// Modification History:
// 		Guangwei Jiang, Aug31'10
//		1. Change the background of PvButton03 when receive the click events.
//
//
// Note:
//    
//==========================================
//
// 
//

package com.wistron.CustomView;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class CustomView extends Activity {
	
	private PvButton	mPvButton01 = null; 
	private PvButton	mPvButton02 = null; 
	private PvButton	mPvButton03 = null; 
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mPvButton01 = (PvButton)findViewById(R.id.mPvButton01);        
        mPvButton01.setOnClickListener(new View.OnClickListener() {			
			public void onClick(View v) {
				Toast.makeText(CustomView.this, "I'm ButterFly, who are you?",
	                    Toast.LENGTH_LONG).show();
			}
		}
        );
        
        mPvButton02 = (PvButton)findViewById(R.id.mPvButton02);        
        mPvButton02.setOnClickListener(new View.OnClickListener() {			
			public void onClick(View v) {
				Toast.makeText(CustomView.this, "I'm Panda, who are you?",
	                    Toast.LENGTH_LONG).show();
			}
		}
        );
        
        mPvButton03 = (PvButton)findViewById(R.id.mPvButton03);        
        mPvButton03.setOnClickListener(new View.OnClickListener() {			
			public void onClick(View v) {
				Drawable drawable = getResources().getDrawable(R.drawable.btn_bg_left_mark_pressed);
				mPvButton03.setBackgroundDrawable(drawable);
				Toast.makeText(CustomView.this, "I'm Tortoise, who are you?",
	                    Toast.LENGTH_LONG).show();
			}
		}
        );
    }
}