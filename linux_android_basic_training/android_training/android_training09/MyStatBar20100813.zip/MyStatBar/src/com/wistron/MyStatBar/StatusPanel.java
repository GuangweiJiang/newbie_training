//==========================================
// Filename:
//      StatusPanel.java
//
// Copyright (C) 2010 Wistron
// All rights reserved.
//
// Description:
//      We will build a View Group, which like the status bar show on the top of the Android.
//		And it will have some special features, like can show current activity name and calling activity name.
//
// Author/Created Date:
//      Guangwei Jiang, Jul20'10
//
// Modification History:
//		Guangwei@Aug13'10
//		1. Update the network/wifi/battery access permission as below, 
//		<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
//		<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
//		<uses-permission android:name="android.permission.BATTERY_STATS" />
//		2. The "StatusPanel" Class sometimes will cause system not stable, will monitor this issue!
// 
//
//
// Note:
// 
//	By Guangwei@Aug12'10
//	The StatusPanel Class is a View Group, its features like the google's status bar, 
//	but has some special custom features, such as can show current/calling activity name.
//	In this version, it has below functions:
//	1. Show current time(Hours:Minutes).
//	2. Show Battery status.
//	3. Show WiFi signal status.
//	4. Show Phone signal strength status, and data type icon.
//	5. Show application name.
//	6. Show current and calling activity name.
//
//	There are some items/issues need your notice,
//	1. This status panel will NOT show the BT status, as the ButterFly don't have BT feature.
//	2. Phone status is complicated, in this version, it only complete part of feature, not all.
//		Complete items: Show Phone Signal, Show Network type
//		Not finish items: SIM card insert status, Roam status 
//	3. Known issues on WiFi: 
//		When do screen rotation, the WiFi signal strength will show very very low, even the signal is full.
//	4. In order to un-register receiver, you must call "onStatusPanelDestroy" in your activity's method "onDestroy".
//	5. In order to get permisson to monitor the network/WiFi/battery state, you should add below line in the "AndroidManifest.xml",
//		<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
//		<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
//		<uses-permission android:name="android.permission.BATTERY_STATS" />
//	6. When you port “StatusPanel” to your project, remember change the package name to your own 
//		(include the StatusPanel.java and your xml layout file).
//
//==========================================
//
// 
//

package com.wistron.MyStatBar;

import java.util.Calendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class StatusPanel extends ViewGroup {
	
    TextView mText01 = null;
    TextView mText02 = null;
    TextView mText03 = null;
    TextView mText04 = null;
	
	ImageView mImage01 = null;
	ImageView mImage02 = null;
	ImageView mImage03 = null;
	ImageView mImage04 = null;
	ImageView mImage05 = null;
	ImageView mImage06 = null;
	
	// clock
    private Calendar mCalendar;
    
    // battery
    private boolean mBatteryFirst = true;
    private boolean mBatteryPlugged = false;
    private int mBatteryLevel = 0;
    
    // wifi
    private static final int[] sWifiSignalImages = new int[] {
        R.drawable.stat_sys_wifi_signal_1,
        R.drawable.stat_sys_wifi_signal_2,
        R.drawable.stat_sys_wifi_signal_3,
        R.drawable.stat_sys_wifi_signal_4,
    };
    private static final int sWifiTemporarilyNotConnectedImage =
        R.drawable.stat_sys_wifi_signal_0;
    private int mLastWifiSignalLevel = -1;
    private boolean mIsWifiConnected = false;
    	
    //phone related 
    //IccCard.State mSimState = IccCard.State.READY;
    int mPhoneState = TelephonyManager.CALL_STATE_IDLE;
    int mDataState = TelephonyManager.DATA_DISCONNECTED;
    int mDataActivity = TelephonyManager.DATA_ACTIVITY_NONE;
    ServiceState mServiceState;
    SignalStrength mSignalStrength;
    
    int mGsmSignalStrength = -1;
    int mCdmaDbm = -1;
    int mCdmaEcio = -1;
    int mEvdoDbm = -1;
    int mEvdoEcio = -1;
    int mEvdoSnr = -1;
    boolean mIsGsm;
    
    private TelephonyManager mPhone;
    
    //***** Signal strength icons
    //GSM/UMTS
    private static final int[] sSignalImages = new int[] {
        R.drawable.stat_sys_signal_0,
        R.drawable.stat_sys_signal_1,
        R.drawable.stat_sys_signal_2,
        R.drawable.stat_sys_signal_3,
        R.drawable.stat_sys_signal_4
    };
    private static final int[] sSignalImages_r = new int[] {
        R.drawable.stat_sys_r_signal_0,
        R.drawable.stat_sys_r_signal_1,
        R.drawable.stat_sys_r_signal_2,
        R.drawable.stat_sys_r_signal_3,
        R.drawable.stat_sys_r_signal_4
    };
    private static final int[] sRoamingIndicatorImages_cdma = new int[] {
        R.drawable.stat_sys_roaming_cdma_0, //Standard Roaming Indicator
        // 1 is Standard Roaming Indicator OFF
        // TODO T: image never used, remove and put 0 instead?
        R.drawable.stat_sys_roaming_cdma_0,

        // 2 is Standard Roaming Indicator FLASHING
        // TODO T: image never used, remove and put 0 instead?
        R.drawable.stat_sys_roaming_cdma_0,

        // 3-12 Standard ERI
        R.drawable.stat_sys_roaming_cdma_0, //3
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,

        // 13-63 Reserved for Standard ERI
        R.drawable.stat_sys_roaming_cdma_0, //13
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,

        // 64-127 Reserved for Non Standard (Operator Specific) ERI
        R.drawable.stat_sys_roaming_cdma_0, //64
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0,
        R.drawable.stat_sys_roaming_cdma_0 //83

        // 128-255 Reserved
    };

    //***** Data connection icons
    private int[] mDataIconList = sDataNetType_g;
    //GSM/UMTS
    private static final int[] sDataNetType_g = new int[] {
            R.drawable.stat_sys_data_connected_g,
            R.drawable.stat_sys_data_in_g,
            R.drawable.stat_sys_data_out_g,
            R.drawable.stat_sys_data_inandout_g,
        };
    private static final int[] sDataNetType_3g = new int[] {
            R.drawable.stat_sys_data_connected_3g,
            R.drawable.stat_sys_data_in_3g,
            R.drawable.stat_sys_data_out_3g,
            R.drawable.stat_sys_data_inandout_3g,
        };
    private static final int[] sDataNetType_e = new int[] {
            R.drawable.stat_sys_data_connected_e,
            R.drawable.stat_sys_data_in_e,
            R.drawable.stat_sys_data_out_e,
            R.drawable.stat_sys_data_inandout_e,
        };
    //3.5G
    private static final int[] sDataNetType_h = new int[] {
            R.drawable.stat_sys_data_connected_h,
            R.drawable.stat_sys_data_in_h,
            R.drawable.stat_sys_data_out_h,
            R.drawable.stat_sys_data_inandout_h,
    };

    //CDMA
    // Use 3G icons for EVDO data and 1x icons for 1XRTT data
    private static final int[] sDataNetType_1x = new int[] {
        R.drawable.stat_sys_data_connected_1x,
        R.drawable.stat_sys_data_in_1x,
        R.drawable.stat_sys_data_out_1x,
        R.drawable.stat_sys_data_inandout_1x,
    };
    	
	public StatusPanel(Context context) {
		super(context);
		initStatusPanel();
	}
	
	public StatusPanel(Context context, AttributeSet attrs) {
		super(context, attrs);				
		initStatusPanel();		
	}

	private void initStatusPanel() {		
		
		mText01 = new TextView(getContext());
		mText01.setTextColor(Color.BLACK);
		mText01.setText("AppName");
		
		mText02 = new TextView(getContext());
		mText02.setTextColor(Color.BLACK);
		mText02.setText("Active01");
		
		Bitmap bmp01 = BitmapFactory.decodeResource(getResources(), R.drawable.ic_menu_back);
		mImage01 = new ImageView(getContext());
		mImage01.setImageBitmap(bmp01);
		
		mText03 = new TextView(getContext());
		mText03.setTextColor(Color.BLACK);
		mText03.setText("Active02");
		
		//Bitmap bmp02 = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_data_bluetooth);
		mImage02 = new ImageView(getContext());
		//mImage02.setImageBitmap(bmp02);
		
		//Bitmap bmp03 = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_wifi_signal_4);
		mImage03 = new ImageView(getContext());
		//mImage03.setImageBitmap(bmp03);
		
		//Bitmap bmp04 = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_data_connected_3g);
		mImage04 = new ImageView(getContext());
		//mImage04.setImageBitmap(bmp04);
		
		//Bitmap bmp05 = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_signal_4);
		mImage05 = new ImageView(getContext());
		//mImage05.setImageBitmap(bmp05);

		//Bitmap bmp06 = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_charge_anim2);
		mImage06 = new ImageView(getContext());
		//mImage06.setImageBitmap(bmp06);
		
		mText04 = new TextView(getContext());
		mText04.setTextColor(Color.BLACK);
		//mText04.setText("11:00AM");
		
		updateClock();

		addView(mText01);
		addView(mText02);
		addView(mImage01);
		addView(mText03);
		addView(mImage02);
		addView(mImage03);
		addView(mImage04);
		addView(mImage05);
		addView(mImage06);
		addView(mText04);
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		int dwTimeFrameWidth = 40;
		int childCount = getChildCount();
		//System.out.println("Child Count = " + childCount);
		
		int i = 0;
		
		int dwChildWidth = b-t;
		int dwChildHeight = b-t;
		int dwChildLeft = 0;
		int dwChildRight = 0;
		
		
		
		for (i = 0; i < childCount; i++)
		{			
		View child = getChildAt(i);

		child.setVisibility(View.VISIBLE);
		child.measure(b-t, b-t);
		
		//Calculate the width of the Views
		if (i == 0)
			dwChildWidth = 100;
		else if (i == 1)
			dwChildWidth = mText02.getMeasuredWidth();
		else if (i == 3)
			dwChildWidth = 70;
		else if (i == 9)
			dwChildWidth = 60;
		else
			dwChildWidth = b-t;
		
		//Calculate the position of the 1st status icon
		if (i == 4)
			dwChildLeft = (r-l) -(b-t)*5 - dwTimeFrameWidth;
		
		dwChildRight = dwChildLeft + dwChildWidth;		
		child.layout(dwChildLeft, 0, dwChildRight, dwChildHeight);
		dwChildLeft = dwChildRight;
		}
		
		initBroadcast();
	}
	
	private final void initBroadcast()
	{		
		// phone_signal
        mPhone = (TelephonyManager)getContext().getSystemService(Context.TELEPHONY_SERVICE);
		
		// register for phone state notifications.
        ((TelephonyManager)getContext().getSystemService(Context.TELEPHONY_SERVICE))
                .listen(mPhoneStateListener,
                          PhoneStateListener.LISTEN_SERVICE_STATE
                        | PhoneStateListener.LISTEN_SIGNAL_STRENGTHS
                        | PhoneStateListener.LISTEN_CALL_STATE
                        | PhoneStateListener.LISTEN_DATA_CONNECTION_STATE
                        | PhoneStateListener.LISTEN_DATA_ACTIVITY);
		
		IntentFilter filter = new IntentFilter();
		
		// Register for Intent broadcasts for...
		// 1st part, Time related events
        filter.addAction(Intent.ACTION_TIME_TICK);
        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_CONFIGURATION_CHANGED);
        filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        // 2nd part, battery/power related events
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(Intent.ACTION_BATTERY_LOW);
        filter.addAction(Intent.ACTION_BATTERY_OKAY);
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        // 3rd part, wifi related events
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.SUPPLICANT_CONNECTION_CHANGE_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        
        getContext().registerReceiver(mIntentReceiver, filter);
		
	}
	
	private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
		
		@Override
        public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			
			// 1st part, time related events
			if (action.equals(Intent.ACTION_TIME_TICK)) {
                updateClock();
            }
			else if (action.equals(Intent.ACTION_TIME_CHANGED)) {
                updateClock();
            }
            else if (action.equals(Intent.ACTION_CONFIGURATION_CHANGED)) {
                updateClock();
            }
            else if (action.equals(Intent.ACTION_TIMEZONE_CHANGED)) {
                updateClock();
            }
			// 2nd part, battery/power related events
            else if (action.equals(Intent.ACTION_BATTERY_CHANGED)) {
                updateBattery(intent);
            }
            else if (action.equals(Intent.ACTION_BATTERY_LOW)) {
                onBatteryLow(intent);
            }
            else if (action.equals(Intent.ACTION_BATTERY_OKAY)
                    || action.equals(Intent.ACTION_POWER_CONNECTED)) {
                onBatteryOkay(intent);
            }
			// 3rd part, wifi related events
            else if (action.equals(WifiManager.NETWORK_STATE_CHANGED_ACTION) ||
                    action.equals(WifiManager.WIFI_STATE_CHANGED_ACTION) ||
                    action.equals(WifiManager.RSSI_CHANGED_ACTION)) {
                updateWifi(intent);
            }			            			
		}		
	};
	
    private final void updateClock() {    	
    	int dwHour, dwMinute; 
    	String strHour, strMinute; 

    	//mCalendar.setTimeInMillis(System.currentTimeMillis());
    	mCalendar = Calendar.getInstance();
    	dwHour = mCalendar.get(Calendar.HOUR_OF_DAY);
    	dwMinute = mCalendar.get(mCalendar.MINUTE);  
    	
    	if (dwHour < 10)
    		strHour = "0" + String.format("%d", dwHour);
    	else
    		strHour = String.format("%d", dwHour);
    	
    	if (dwMinute < 10)
    		strMinute = "0" + String.format("%d", dwMinute);
    	else
    		strMinute = String.format("%d", dwMinute);
    	
    	mText04.setText(strHour + ":" + strMinute);    	
    }
	
    private final void updateBattery(Intent intent) {
    	Bitmap batteryImg;
    	boolean plugged = intent.getIntExtra("plugged", 0) != 0;
    	int level = intent.getIntExtra("level", -1);
    	
    	boolean oldPlugged = mBatteryPlugged;
    	int oldLevel = mBatteryLevel;

        mBatteryPlugged = plugged;
        mBatteryLevel = level;
        
        if ((oldPlugged!=mBatteryPlugged)||(oldLevel!=mBatteryLevel) || mBatteryFirst)
        {
        	if (mBatteryFirst) 
                mBatteryFirst = false;
        	
        	// do battery icon update 
        	if (mBatteryLevel >= 0 && mBatteryLevel < 10)
        	{
        		if(mBatteryPlugged)        			
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_charge_anim0);
        		else
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_0);
        	}
        	if (mBatteryLevel >= 10 && mBatteryLevel <20)
        	{
        		if(mBatteryPlugged)        			
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_charge_anim0);
        		else
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_10);
        	}
        	else if (mBatteryLevel >= 20 && mBatteryLevel <40)
        	{
        		if(mBatteryPlugged)        			
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_charge_anim1);
        		else
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_20);
        	}
        	else if (mBatteryLevel >= 40 && mBatteryLevel <60)
        	{
        		if(mBatteryPlugged)        			
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_charge_anim2);
        		else
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_40);
        	}
        	else if (mBatteryLevel >= 60 && mBatteryLevel < 80)
        	{
        		if(mBatteryPlugged)        			
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_charge_anim3);
        		else
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_60);
        	}
        	else if (mBatteryLevel >= 80 && mBatteryLevel < 95)
        	{
        		if(mBatteryPlugged)        			
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_charge_anim4);
        		else
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_80);
        	}
        	else if (mBatteryLevel > 95 && mBatteryLevel <=100)
        	{
        		if(mBatteryPlugged)        			
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_charge_anim5);
        		else
        			batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_100);
        	}
        	else
        	{
        		batteryImg = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_battery_unknown);
        	}
        	
        	mImage06.setImageBitmap(batteryImg);        	
        }        
    }

    private void onBatteryLow(Intent intent) {
    	//Toast.makeText(getContext(), "onBatteryLow", Toast.LENGTH_LONG).show();
        /*if (SHOW_LOW_BATTERY_WARNING) {
            if (false) {
                Log.d(TAG, "mPhoneState=" + mPhoneState
                      + " mLowBatteryDialog=" + mLowBatteryDialog
                      + " mBatteryShowLowOnEndCall=" + mBatteryShowLowOnEndCall);
            }

            if (mPhoneState == TelephonyManager.CALL_STATE_IDLE) {
                showLowBatteryWarning();
            } else {
                mBatteryShowLowOnEndCall = true;
            }
        }*/
    }

    private void onBatteryOkay(Intent intent) {
    	//Toast.makeText(getContext(), "onBatteryOkay", Toast.LENGTH_LONG).show();
        /*if (mLowBatteryDialog != null
                && SHOW_LOW_BATTERY_WARNING) {
            mLowBatteryDialog.dismiss();
            mBatteryShowLowOnEndCall = false;
        }*/
    }
    
    private final void updateWifi(Intent intent) {
    	Bitmap wifiImage = null;
        final String action = intent.getAction();
        if (action.equals(WifiManager.WIFI_STATE_CHANGED_ACTION)) {

            final boolean enabled = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE,
                    WifiManager.WIFI_STATE_UNKNOWN) == WifiManager.WIFI_STATE_ENABLED;

            if (!enabled) {
                // If disabled, hide the icon. (We show icon when connected.)
            	mImage03.setVisibility(View.INVISIBLE);
            }

        } else if (action.equals(WifiManager.SUPPLICANT_CONNECTION_CHANGE_ACTION)) {
            final boolean enabled = intent.getBooleanExtra(WifiManager.EXTRA_SUPPLICANT_CONNECTED,
                                                           false);
            if (!enabled) {
            	mImage03.setVisibility(View.INVISIBLE);
            }
        } else if (action.equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {

            final NetworkInfo networkInfo = (NetworkInfo)
                    intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);

            int iconId;
            if (networkInfo != null && networkInfo.isConnected()) {
                mIsWifiConnected = true;
                if (mLastWifiSignalLevel == -1) {
                	wifiImage = BitmapFactory.decodeResource(getResources(), sWifiSignalImages[0]);
                } else {
                	wifiImage = BitmapFactory.decodeResource(getResources(), sWifiSignalImages[mLastWifiSignalLevel]);
                }

                // Show the icon since wi-fi is connected
                mImage03.setImageBitmap(wifiImage);
                mImage03.setVisibility(View.VISIBLE);
                //Toast.makeText(getContext(), "updateWifi: show the wifi is connected", Toast.LENGTH_LONG).show();

            } else {
                mLastWifiSignalLevel = -1;
                mIsWifiConnected = false;

                // Hide the icon since we're not connected
                mImage03.setVisibility(View.INVISIBLE);
                //Toast.makeText(getContext(), "updateWifi: hide wifi icon as not connect", Toast.LENGTH_LONG).show();
            }
        } else if (action.equals(WifiManager.RSSI_CHANGED_ACTION)) {
            final int newRssi = intent.getIntExtra(WifiManager.EXTRA_NEW_RSSI, -200);
            int newSignalLevel = WifiManager.calculateSignalLevel(newRssi,
                                                                  sWifiSignalImages.length);
            if (newSignalLevel != mLastWifiSignalLevel) {
                mLastWifiSignalLevel = newSignalLevel;
                if (mIsWifiConnected) {
                	wifiImage = BitmapFactory.decodeResource(getResources(), sWifiSignalImages[newSignalLevel]);
                	//Toast.makeText(getContext(), String.format("updateWifi: rssi is %d", mLastWifiSignalLevel), Toast.LENGTH_LONG).show();
                } else {
                	wifiImage = BitmapFactory.decodeResource(getResources(), sWifiTemporarilyNotConnectedImage);
                	//Toast.makeText(getContext(), "updateWifi: WifiTemporarilyNotConnected", Toast.LENGTH_LONG).show();
                }
                mImage03.setImageBitmap(wifiImage);
                mImage03.setVisibility(View.VISIBLE);
            }
        }
    }
    
    
    
    private PhoneStateListener mPhoneStateListener = new PhoneStateListener() {
        @Override
        public void onSignalStrengthsChanged(SignalStrength signalStrength) {
            
        	mGsmSignalStrength = signalStrength.getGsmSignalStrength();
        	mCdmaDbm = signalStrength.getCdmaDbm();
        	mCdmaEcio = signalStrength.getCdmaEcio();
        	mEvdoDbm = signalStrength.getEvdoDbm();
        	mEvdoEcio = signalStrength.getEvdoEcio();
        	mEvdoSnr = signalStrength.getEvdoSnr();
        	mIsGsm = signalStrength.isGsm();
        	
            updateSignalStrength();       
        }

        @Override
        public void onServiceStateChanged(ServiceState state) {
            mServiceState = state;
            updateSignalStrength();
            updateCdmaRoamingIcon(state);
            updateDataIcon();
            
        }

        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            //updateCallState(state);
            // In cdma, if a voice call is made, RSSI should switch to 1x.
            if (isCdma()) {
                updateSignalStrength();
            }
            
        }

        @Override
        public void onDataConnectionStateChanged(int state, int networkType) {
            mDataState = state;
            updateDataNetType(networkType);
            updateDataIcon();
        }

        @Override
        public void onDataActivity(int direction) {
            mDataActivity = direction;
            updateDataIcon();
            
        }
    };
    
    private boolean isCdma() {
        //return (mSignalStrength != null) && !mSignalStrength.isGsm();
    	boolean bRet = false;
    	
    	//get radio type
    	int type = mPhone.getPhoneType();
    	
    	if (type == TelephonyManager.NETWORK_TYPE_CDMA)
    		bRet = true;
    	
    	return bRet;  
    }
    
    private boolean isEvdo() {
    	boolean bRet = false;
    	
    	//get radio type
    	int type = mPhone.getPhoneType();
    	
    	if ((type == TelephonyManager.NETWORK_TYPE_EVDO_0)
    			|| (type == TelephonyManager.NETWORK_TYPE_EVDO_A))
    		bRet = true;
    	
    	return bRet;    	        
    }

    private boolean hasService() {
        if (mServiceState != null) {
            switch (mServiceState.getState()) {
                case ServiceState.STATE_OUT_OF_SERVICE:
                case ServiceState.STATE_POWER_OFF:
                    return false;
                default:
                    return true;
            }
        } else {
            return false;
        }
    }


    private final void updateSignalStrength() {
    	int iconLevel = -1;
        int[] iconList;
        Bitmap bmp05;
		
        
        if (!hasService()) {
            //Log.d(TAG, "updateSignalStrength: no service");
            if (Settings.System.getInt(getContext().getContentResolver(),
                    Settings.System.AIRPLANE_MODE_ON, 0) == 1) {
                bmp05 = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_signal_flightmode);
            } else {
                bmp05 = BitmapFactory.decodeResource(getResources(), R.drawable.stat_sys_signal_null);
            }
            mImage05.setImageBitmap(bmp05);
            return;
        }
        
        if (!isCdma()) {
            //int asu = mSignalStrength.getGsmSignalStrength();
        	int asu = mGsmSignalStrength;

            // ASU ranges from 0 to 31 - TS 27.007 Sec 8.5
            // asu = 0 (-113dB or less) is very weak
            // signal, its better to show 0 bars to the user in such cases.
            // asu = 99 is a special case, where the signal strength is unknown.
            if (asu <= 0 || asu == 99) iconLevel = 0;
            else if (asu >= 16) iconLevel = 4;
            else if (asu >= 8)  iconLevel = 3;
            else if (asu >= 4)  iconLevel = 2;
            else iconLevel = 1;

            // Though mPhone is a Manager, this call is not an IPC
            if (mPhone.isNetworkRoaming()) {
                iconList = sSignalImages_r;
            } else {
                iconList = sSignalImages;
            }
        }
        else {
            iconList = this.sSignalImages;

            // If 3G(EV) and 1x network are available than 3G should be
            // displayed, displayed RSSI should be from the EV side.
            // If a voice call is made then RSSI should switch to 1x.
            if ((mPhoneState == TelephonyManager.CALL_STATE_IDLE) && isEvdo()){
                iconLevel = getEvdoLevel();                
            } else {
                iconLevel = getCdmaLevel();
            }
        }
        
        bmp05 = BitmapFactory.decodeResource(getResources(), iconList[iconLevel]);
        mImage05.setImageBitmap(bmp05);
             
    }
    
    
    private int getCdmaLevel() {
        final int cdmaDbm = mCdmaDbm;
        final int cdmaEcio = mCdmaEcio;
        int levelDbm = 0;
        int levelEcio = 0;

        if (cdmaDbm >= -75) levelDbm = 4;
        else if (cdmaDbm >= -85) levelDbm = 3;
        else if (cdmaDbm >= -95) levelDbm = 2;
        else if (cdmaDbm >= -100) levelDbm = 1;
        else levelDbm = 0;

        // Ec/Io are in dB*10
        if (cdmaEcio >= -90) levelEcio = 4;
        else if (cdmaEcio >= -110) levelEcio = 3;
        else if (cdmaEcio >= -130) levelEcio = 2;
        else if (cdmaEcio >= -150) levelEcio = 1;
        else levelEcio = 0;

        return (levelDbm < levelEcio) ? levelDbm : levelEcio;
    }

    private int getEvdoLevel() {
        int evdoDbm = mEvdoDbm;
        int evdoSnr = mEvdoSnr;
        int levelEvdoDbm = 0;
        int levelEvdoSnr = 0;

        if (evdoDbm >= -65) levelEvdoDbm = 4;
        else if (evdoDbm >= -75) levelEvdoDbm = 3;
        else if (evdoDbm >= -90) levelEvdoDbm = 2;
        else if (evdoDbm >= -105) levelEvdoDbm = 1;
        else levelEvdoDbm = 0;

        if (evdoSnr >= 7) levelEvdoSnr = 4;
        else if (evdoSnr >= 5) levelEvdoSnr = 3;
        else if (evdoSnr >= 3) levelEvdoSnr = 2;
        else if (evdoSnr >= 1) levelEvdoSnr = 1;
        else levelEvdoSnr = 0;

        return (levelEvdoDbm < levelEvdoSnr) ? levelEvdoDbm : levelEvdoSnr;
    }
    
    
    private final void updateDataNetType(int net) {

        switch (net) {
        case TelephonyManager.NETWORK_TYPE_EDGE:
            mDataIconList = sDataNetType_e;
            break;
        case TelephonyManager.NETWORK_TYPE_UMTS:
            mDataIconList = sDataNetType_3g;
            break;
        case TelephonyManager.NETWORK_TYPE_HSDPA:
        case TelephonyManager.NETWORK_TYPE_HSUPA:
        case TelephonyManager.NETWORK_TYPE_HSPA:
        	//Not sure why "distinguish the Data icon", so we only use "h" icon, By Guangwei@Aug10'10
            //if (mHspaDataDistinguishable) {
            //    mDataIconList = sDataNetType_h;
            //} else {
            //    mDataIconList = sDataNetType_3g;
            //}
        	mDataIconList = sDataNetType_h;
            break;
        case TelephonyManager.NETWORK_TYPE_CDMA:
            // display 1xRTT for IS95A/B
            mDataIconList = this.sDataNetType_1x;
            break;
        case TelephonyManager.NETWORK_TYPE_1xRTT:
            mDataIconList = this.sDataNetType_1x;
            break;
        case TelephonyManager.NETWORK_TYPE_EVDO_0: //fall through
        case TelephonyManager.NETWORK_TYPE_EVDO_A:
            mDataIconList = sDataNetType_3g;
            break;
        default:
            mDataIconList = sDataNetType_g;
        	
        break;
        }
        
        Bitmap bmp04 = BitmapFactory.decodeResource(getResources(), mDataIconList[0]);
        mImage04.setImageBitmap(bmp04);
    }
    
    private final void updateDataIcon() {
        /*int iconId;
        boolean visible = true;

        if (!isCdma()) {
            // GSM case, we have to check also the sim state
            if (mSimState == IccCard.State.READY || mSimState == IccCard.State.UNKNOWN) {
                if (hasService() && mDataState == TelephonyManager.DATA_CONNECTED) {
                    switch (mDataActivity) {
                        case TelephonyManager.DATA_ACTIVITY_IN:
                            iconId = mDataIconList[1];
                            break;
                        case TelephonyManager.DATA_ACTIVITY_OUT:
                            iconId = mDataIconList[2];
                            break;
                        case TelephonyManager.DATA_ACTIVITY_INOUT:
                            iconId = mDataIconList[3];
                            break;
                        default:
                            iconId = mDataIconList[0];
                            break;
                    }
                    mDataData.iconId = iconId;
                    mService.updateIcon(mDataIcon, mDataData, null);
                } else {
                    visible = false;
                }
            } else {
                mDataData.iconId = com.android.internal.R.drawable.stat_sys_no_sim;
                mService.updateIcon(mDataIcon, mDataData, null);
            }
        } else {
            // CDMA case, mDataActivity can be also DATA_ACTIVITY_DORMANT
            if (hasService() && mDataState == TelephonyManager.DATA_CONNECTED) {
                switch (mDataActivity) {
                    case TelephonyManager.DATA_ACTIVITY_IN:
                        iconId = mDataIconList[1];
                        break;
                    case TelephonyManager.DATA_ACTIVITY_OUT:
                        iconId = mDataIconList[2];
                        break;
                    case TelephonyManager.DATA_ACTIVITY_INOUT:
                        iconId = mDataIconList[3];
                        break;
                    case TelephonyManager.DATA_ACTIVITY_DORMANT:
                    default:
                        iconId = mDataIconList[0];
                        break;
                }
                mDataData.iconId = iconId;
                mService.updateIcon(mDataIcon, mDataData, null);
            } else {
                visible = false;
            }
        }

        long ident = Binder.clearCallingIdentity();
        try {
            mBatteryStats.notePhoneDataConnectionState(mPhone.getNetworkType(), visible);
        } catch (RemoteException e) {
        } finally {
            Binder.restoreCallingIdentity(ident);
        }

        if (mDataIconVisible != visible) {
            mService.setIconVisibility(mDataIcon, visible);
            mDataIconVisible = visible;
        }*/
    }
    
    private final void updateCdmaRoamingIcon(ServiceState state) {
        /*if (!hasService()) {
            mService.setIconVisibility(mCdmaRoamingIndicatorIcon, false);
            return;
        }

        if (!isCdma()) {
            mService.setIconVisibility(mCdmaRoamingIndicatorIcon, false);
            return;
        }

        int[] iconList = sRoamingIndicatorImages_cdma;
        int iconIndex = state.getCdmaEriIconIndex();
        int iconMode = state.getCdmaEriIconMode();

        if (iconIndex == -1) {
            Log.e(TAG, "getCdmaEriIconIndex returned null, skipping ERI icon update");
            return;
        }

        if (iconMode == -1) {
            Log.e(TAG, "getCdmeEriIconMode returned null, skipping ERI icon update");
            return;
        }

        if (iconIndex == EriInfo.ROAMING_INDICATOR_OFF) {
            if (false) Log.v(TAG, "Cdma ROAMING_INDICATOR_OFF, removing ERI icon");
            mService.setIconVisibility(mCdmaRoamingIndicatorIcon, false);
            return;
        }

        switch (iconMode) {
            case EriInfo.ROAMING_ICON_MODE_NORMAL:
                mCdmaRoamingIndicatorIconData.iconId = iconList[iconIndex];
                mService.updateIcon(mCdmaRoamingIndicatorIcon, mCdmaRoamingIndicatorIconData, null);
                mService.setIconVisibility(mCdmaRoamingIndicatorIcon, true);
                break;
            case EriInfo.ROAMING_ICON_MODE_FLASH:
                mCdmaRoamingIndicatorIconData.iconId =
                        com.android.internal.R.drawable.stat_sys_roaming_cdma_flash;
                mService.updateIcon(mCdmaRoamingIndicatorIcon, mCdmaRoamingIndicatorIconData, null);
                mService.setIconVisibility(mCdmaRoamingIndicatorIcon, true);
                break;

        }
        mService.updateIcon(mPhoneIcon, mPhoneData, null);*/
    }
    
    // The registered receiver must un-register
    // Please call this method when Activiy destroy.
    public void onStatusPanelDestroy()
    {
    	getContext().unregisterReceiver(mIntentReceiver);
    }
  
	
    public void setAppName(String text) {
    	mText01.setText(text);    	
    }
    
    public void setCallingActivityName(String text) {
    	mText02.setText(text);    	
    }
    
    public void setCurrentActivityName(String text) {
    	mText03.setText(text);    	
    }
}
