//==========================================
// Filename:
//      MyStatBar.java
//
// Copyright (C) 2010 Wistron
// All rights reserved.
//
// Description:
//      This is a demo to show how to use ViewGoup "StatusPanel".
//
// Author/Created Date:
//      Guangwei Jiang, Aug12'10
//
// Modification History:
// 
//
//
// Note:
// 
//
//==========================================
//
// 
//

package com.wistron.MyStatBar;

import android.app.Activity;
import android.os.Bundle;

public class MyStatBar extends Activity {
	StatusPanel mStatusPanel = null;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mStatusPanel = (StatusPanel)findViewById(R.id.mStatusPanel);
        mStatusPanel.setAppName("MyStatBar");
        mStatusPanel.setCallingActivityName("Home");
        mStatusPanel.setCurrentActivityName("MyStatBar");
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        
        mStatusPanel.onStatusPanelDestroy();
    }
}